# J.A.R.V.I.S. AI — Android v1.0

Protótipo nativo Android em Kotlin + Jetpack Compose.

## O que já está implementado
- Interface holográfica azul com núcleo pulsante.
- Reconhecimento de fala em português brasileiro (usa o serviço de voz disponível no Android).
- Resposta falada com Android Text-to-Speech e pitch mais grave.
- Comandos básicos para abrir WhatsApp, YouTube, Chrome, Instagram e Configurações.
- Resposta com horário atual.

## Limitações desta primeira versão
- O botão inicia uma sessão de reconhecimento; a palavra "Jarvis" ainda não fica escutando continuamente.
- A voz grave depende das vozes instaladas no mecanismo de TTS do aparelho. Para uma voz neural muito realista será necessária uma integração de serviço externo.
- A IA conversacional ainda não está conectada. A próxima etapa será adicionar um backend/API com chave protegida no servidor.
- Não há acesso irrestrito ao aparelho: o Android exige permissões e limita ações em segundo plano.

## Gerar o APK
O workflow `.github/workflows/build-apk.yml` compila o APK de depuração no GitHub Actions.
1. Envie este projeto para um repositório GitHub.
2. Abra a aba **Actions**.
3. Execute **Build JARVIS APK** (ou faça push na branch `main`).
4. Baixe o artefato `jarvis-debug-apk`.
5. Extraia `app-debug.apk` e instale no Android. Talvez seja necessário autorizar a instalação dessa fonte.

## Identificadores
- Application ID: `com.jarvis.ai`
- Versão: `1.0`
- Min Android: Android 8.0 (API 26)
