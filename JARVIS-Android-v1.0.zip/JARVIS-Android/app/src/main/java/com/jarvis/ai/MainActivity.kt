package com.jarvis.ai

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import java.util.Locale

private val Deep = Color(0xFF020914)
private val Cyan = Color(0xFF36D9FF)
private val Blue = Color(0xFF147BFF)

class MainActivity : ComponentActivity(), TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private var onHeard: ((String) -> Unit)? = null
    private var onStatus: ((String) -> Unit)? = null

    private val micPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) startRecognition()
        else onStatus?.invoke("Permissão do microfone necessária.")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        tts = TextToSpeech(this, this)
        setContent {
            var status by remember { mutableStateOf("SISTEMA PRONTO") }
            var transcript by remember { mutableStateOf("Aguardando suas instruções, senhor.") }
            onStatus = { status = it }
            onHeard = { phrase ->
                transcript = phrase
                handleCommand(phrase) { answer ->
                    transcript = answer
                    speak(answer)
                    status = "J.A.R.V.I.S. ONLINE"
                }
            }
            JarvisScreen(
                status = status,
                transcript = transcript,
                onMic = {
                    status = "OUVINDO..."
                    if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO)
                        == PackageManager.PERMISSION_GRANTED) startRecognition()
                    else micPermission.launch(Manifest.permission.RECORD_AUDIO)
                },
                onSpeakTest = {
                    speak("À sua disposição, senhor. Sistemas principais operacionais.")
                }
            )
        }
    }

    override fun onInit(result: Int) {
        if (result == TextToSpeech.SUCCESS) {
            tts?.language = Locale("pt", "BR")
            tts?.setPitch(0.78f)
            tts?.setSpeechRate(0.88f)
        }
    }

    private fun speak(text: String) {
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "jarvis_reply")
    }

    private fun startRecognition() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            onStatus?.invoke("Reconhecimento de voz indisponível neste aparelho.")
            return
        }
        speechRecognizer?.destroy()
        speechRecognizer = SpeechRecognizer.createSpeechRecognizer(this)
        speechRecognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) { onStatus?.invoke("ESTOU OUVINDO") }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { onStatus?.invoke("PROCESSANDO") }
            override fun onError(error: Int) { onStatus?.invoke("NÃO ENTENDI. TENTE NOVAMENTE.") }
            override fun onResults(results: Bundle?) {
                val words = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                words?.firstOrNull()?.let { onHeard?.invoke(it) }
            }
            override fun onPartialResults(partialResults: Bundle?) {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "pt-BR")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "Diga seu comando para o Jarvis")
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        speechRecognizer?.startListening(intent)
    }

    private fun handleCommand(raw: String, reply: (String) -> Unit) {
        val text = raw.lowercase(Locale("pt", "BR"))
        when {
            "whatsapp" in text -> openApp("com.whatsapp", "Abrindo o WhatsApp, senhor.", reply)
            "youtube" in text -> openApp("com.google.android.youtube", "Abrindo o YouTube, senhor.", reply)
            "chrome" in text || "navegador" in text -> openApp("com.android.chrome", "Abrindo o navegador.", reply)
            "instagram" in text -> openApp("com.instagram.android", "Abrindo o Instagram.", reply)
            "configurações" in text || "configuracoes" in text ->
                runCatching { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)) }
                    .onSuccess { reply("Abrindo as configurações do sistema.") }
                    .onFailure { reply("Não consegui abrir as configurações.") }
            "que horas" in text || "horas" == text.trim() ->
                reply("Agora são " + java.text.SimpleDateFormat("HH:mm", Locale("pt", "BR")).format(java.util.Date()) + ", senhor.")
            "jarvis" in text -> reply("À sua disposição, senhor. Como posso ajudar?")
            else -> reply("Recebi seu comando: $raw. Minha conexão com a inteligência artificial ainda será configurada.")
        }
    }

    private fun openApp(packageName: String, success: String, reply: (String) -> Unit) {
        val launch = packageManager.getLaunchIntentForPackage(packageName)
        if (launch != null) {
            runCatching { startActivity(launch) }
                .onSuccess { reply(success) }
                .onFailure { reply("Não consegui abrir esse aplicativo.") }
        } else reply("Esse aplicativo não foi encontrado ou não está instalado.")
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        tts?.stop()
        tts?.shutdown()
        super.onDestroy()
    }
}

@Composable
private fun JarvisScreen(
    status: String,
    transcript: String,
    onMic: () -> Unit,
    onSpeakTest: () -> Unit
) {
    val infinite = rememberInfiniteTransition(label = "core")
    val pulse by infinite.animateFloat(
        initialValue = 0.92f, targetValue = 1.08f,
        animationSpec = infiniteRepeatable(tween(1500), RepeatMode.Reverse),
        label = "pulse"
    )
    MaterialTheme(colorScheme = darkColorScheme(
        background = Deep, surface = Color(0xFF07182A), primary = Cyan
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF06182A), Deep, Color(0xFF01040A)))
            ).padding(22.dp)
        ) {
            Column(
                Modifier.fillMaxSize(),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("STARK INDUSTRIES", color = Cyan.copy(alpha = .7f), fontSize = 11.sp, letterSpacing = 4.sp)
                    Spacer(Modifier.height(10.dp))
                    Text("J.A.R.V.I.S.", color = Color.White, fontSize = 31.sp, fontWeight = FontWeight.Light, letterSpacing = 5.sp)
                    Text("PERSONAL AI SYSTEM  //  v1.0", color = Cyan, fontSize = 9.sp, letterSpacing = 2.sp)
                }

                Box(contentAlignment = Alignment.Center, modifier = Modifier.size(270.dp)) {
                    Box(Modifier.size(250.dp).border(1.dp, Cyan.copy(alpha = .22f), CircleShape))
                    Box(Modifier.size(205.dp).border(1.dp, Blue.copy(alpha = .4f), CircleShape))
                    Box(Modifier.size(160.dp).border(2.dp, Cyan.copy(alpha = .65f), CircleShape))
                    Box(
                        Modifier.size((112 * pulse).dp)
                            .shadow(28.dp, CircleShape, ambientColor = Cyan, spotColor = Blue)
                            .background(Brush.radialGradient(listOf(Color(0xFFB9F7FF), Cyan, Blue, Color(0xFF06335C))), CircleShape)
                            .border(2.dp, Color.White.copy(alpha = .65f), CircleShape)
                    )
                    Text("◈", color = Color.White, fontSize = 36.sp)
                }

                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(status, color = Cyan, fontSize = 12.sp, letterSpacing = 3.sp)
                    Spacer(Modifier.height(14.dp))
                    Surface(
                        color = Color(0xFF07182A).copy(alpha = .85f),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Cyan.copy(alpha = .28f))
                    ) {
                        Text(transcript, color = Color.White, modifier = Modifier.padding(16.dp), fontSize = 14.sp)
                    }
                    Spacer(Modifier.height(22.dp))
                    Button(
                        onClick = onMic,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF087EAE)),
                        shape = RoundedCornerShape(30.dp),
                        modifier = Modifier.fillMaxWidth().height(56.dp)
                    ) {
                        Text("◉   FALAR COM JARVIS", letterSpacing = 2.sp, fontSize = 13.sp)
                    }
                    TextButton(onClick = onSpeakTest) {
                        Text("TESTAR VOZ DO ASSISTENTE", color = Cyan.copy(alpha = .8f), fontSize = 11.sp)
                    }
                }
                Text("VOICE INTERFACE  •  ANDROID", color = Cyan.copy(alpha = .35f), fontSize = 9.sp, letterSpacing = 2.sp)
            }
        }
    }
}
